# make-slides

[![Build Status](https://travis-ci.com/Arish-Shah/make-slides.svg?branch=master)](https://travis-ci.com/Arish-Shah/make-slides) [![GitHub license](https://img.shields.io/github/license/Arish-Shah/make-slides)](https://github.com/Arish-Shah/make-slides/blob/master/LICENSE) [![Twitter](https://img.shields.io/twitter/url/https/github.com/Arish-Shah/make-slides?style=social)](https://twitter.com/intent/tweet?text=Wow:&url=https%3A%2F%2Fgithub.com%2FArish-Shah%2Fmake-slides)
JavaScript presentation library.\
[View demo](https://arish-shah.github.io/make-slides)
